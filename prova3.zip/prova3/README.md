
criar no mongo o banco "reserva"

npm i 

npm run start

Acessar localhost:3000
